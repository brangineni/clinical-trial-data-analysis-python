import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv("sample_clinical_data.csv")

print(data.head())

sns.countplot(x="Treatment_Group", data=data)
plt.show()
